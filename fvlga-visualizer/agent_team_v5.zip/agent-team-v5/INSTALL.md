# Agent team v5 — install
1. Copy `agents/*` into your project's `.claude/agents/` (17 files: 13 agents + README, style, contracts, voice).
2. Copy `fvlga-visualizer/` into the project root (keeps the paths the agents reference):
   - `references/underground_playbook.md` — 7 archetypes + rules (style.md makes them binding)
   - `references/rage_transition_bible.md` — 20 transitions + deployment rules (70-20-10)
   - `render.json` — output format (CUFF NO DANCER: 9:16 with the 16:9 strip at y=656)
   - `src/transitions.py` — reusable transition presets (shake_rgb, zoom_punch, camera_drop, vhs_tracking, flash, exposure_burn_in/out)
   - `src/stickers.py`, `src/cutstill.py` — cut-out sticker pop-ups (u2net person segmentation)
   - `src/plan23.py` — example transition planner (structure map -> 70-20-10 -> one clip per transition)
3. Start a session and ask for an agent by name ("use visualizer-qa on v23") or a stage ("run stage 2 for the new song").

Changes since v4: playbook + transition bible wired into style.md / contracts.md / reference-analyst;
CUFF NO DANCER per-project notes filled; BPM 148 confirmed; voice.md drafted (edit freely);
exposure-burn transition measured from the artist's stairs clip.
